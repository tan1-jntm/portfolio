'use strict';

const { execFile } = require('node:child_process');
const { get } = require('node:http');

function getLocal(port, path) {
  return new Promise((resolve, reject) => {
    const request = get({ host: '127.0.0.1', port, path, timeout: 1600 }, response => {
      if (response.statusCode !== 200) {
        response.resume();
        reject(new Error(`HTTP ${response.statusCode}`));
        return;
      }
      response.setEncoding('utf8');
      let body = '';
      response.on('data', chunk => {
        body += chunk;
        if (body.length > 1024 * 1024) request.destroy(new Error('响应超出预期'));
      });
      response.once('error', reject);
      response.once('end', () => resolve(body));
    });
    request.once('timeout', () => request.destroy(new Error('连接超时')));
    request.once('error', reject);
  });
}

async function checkApp(port) {
  const [infoBody, page] = await Promise.all([getLocal(port, '/api/info'), getLocal(port, '/')]);
  const info = JSON.parse(infoBody);
  if (info.port !== port || !Array.isArray(info.addresses) || !Number.isInteger(info.bankCount) || !page.includes('globalThis.FinalsLan')) {
    throw new Error('端口上的服务不是三机联机模拟器。');
  }
  return info;
}

function openBrowser(url) {
  execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Start-Process '${url}'`], { windowsHide: true }, error => {
    if (error) {
      console.error('没能自动打开浏览器，请在浏览器地址栏打开上面的主机入口。');
      process.exitCode = 1;
    }
  });
}

async function start() {
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('请在主机上使用 Node.js 22 或更新版本。');
  const flag = process.argv.indexOf('--port');
  const port = Number((flag >= 0 ? process.argv[flag + 1] ?? '' : process.env.FINALS_PORT) ?? 8765);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('端口应为 1 至 65535 之间的整数。');

  const { createServer } = require('./lan-server.cjs');
  const server = createServer();
  const ownsServer = await new Promise((resolve, reject) => {
    server.once('error', error => error.code === 'EADDRINUSE' ? resolve(false) : reject(error));
    server.listen(port, '0.0.0.0', () => resolve(true));
  });
  let info;
  try {
    info = await checkApp(port);
  } catch (error) {
    if (ownsServer) {
      server.close();
      throw new Error(`主机页面没能启动。请先完整解压联机包。(${error.message})`);
    }
    throw new Error(`端口 ${port} 已被其他服务占用。可用 --port 8766 换一个端口。`);
  }

  const localUrl = `http://127.0.0.1:${port}/`;
  console.log(ownsServer ? '三人联机已启动' : '已打开正在运行的三人联机主机');
  console.log(`主机入口  ${localUrl}`);
  for (const url of info.addresses) console.log(`队友入口  ${url}`);
  if (!info.addresses.length) console.log('还没找到局域网地址。主机和队友请连接同一个 Wi-Fi 或手机热点。');
  console.log('开房后把页面上的同一条邀请链接发给两位队友。');
  if (ownsServer) console.log('比赛期间请保持这个窗口开启。');
  if (!process.argv.includes('--no-open')) openBrowser(localUrl);
}

if (require.main === module) {
  start().catch(error => {
    console.error(error.message);
    process.exitCode = 1;
  });
}

module.exports = { checkApp };
