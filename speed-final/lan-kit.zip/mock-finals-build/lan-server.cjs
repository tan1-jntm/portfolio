'use strict';

const http = require('node:http');
const os = require('node:os');
const { readFile } = require('node:fs/promises');
const path = require('node:path');
const { randomBytes, randomInt } = require('node:crypto');

require('./engine.js');
const engine = globalThis.FinalsEngine;
const bank = require('./questions.json');
const defaultPort = 8765;
const pageName = 'AI信息素养大赛_决赛极速对抗联机.html';
const pagePath = path.join(__dirname, '..', pageName);
const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
const maxRooms = 32;
const idleMs = 8 * 60 * 60 * 1000;
const presenceMs = 4000;
const recoveryLength = 12;
const seats = [1, 2, 3];

function failure(status, message, snapshot) {
  return Object.assign(new Error(message), { status, snapshot });
}

function participant(room, name, seat, host, now) {
  if (name !== undefined && name !== null && typeof name !== 'string') throw failure(400, '队员名应为文字。');
  const clean = (name ?? '').trim();
  if (Array.from(clean).length > 24) throw failure(400, '队员名最多 24 个字符。');
  let recoveryCode;
  do { recoveryCode = randomCode(recoveryLength); } while (ownerOfRecoveryCode(room, recoveryCode));
  return { name: clean || (seat === null ? '主持人' : `第 ${seat} 位队员`), seat, host, token: newToken(), recoveryCode, seenAt: now };
}

function randomCode(length) {
  return Array.from({ length }, () => alphabet[randomInt(alphabet.length)]).join('');
}

function newToken() {
  return randomBytes(24).toString('base64url');
}

function ownerOfRecoveryCode(room, code) {
  for (const member of room.members.values()) if (member.recoveryCode === code) return member;
  return null;
}

function lanAddresses(port) {
  const candidates = Object.entries(os.networkInterfaces()).flatMap(([name, entries]) => (entries ?? []).filter(info =>
    (info.family === 'IPv4' || info.family === 4) && !info.internal && !info.address.startsWith('169.254.')).map(info => ({ name, address: info.address })));
  const physical = candidates.filter(candidate => !/vmware|virtualbox|vethernet|hyper-v|loopback|wsl|docker|vpn|tailscale|zerotier|tap-|tun\d|virtual|虚拟/i.test(candidate.name));
  const addresses = (physical.length ? physical : candidates).map(info => `http://${info.address}:${port}`);
  return [...new Set(addresses)];
}

function sendJSON(response, status, data) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  response.end(JSON.stringify(data));
}

async function readJSON(request) {
  if (!/^application\/json(?:\s*;|\s*$)/i.test(request.headers['content-type'] || '')) throw failure(415, '请以 JSON 提交房间操作。');
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size <= 4096) chunks.push(chunk);
  }
  if (size > 4096) throw failure(413, '操作内容太长。');
  try {
    const data = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new TypeError();
    return data;
  } catch {
    throw failure(400, '操作内容格式有误。');
  }
}

function occupied(room) {
  const members = new Map();
  for (const member of room.members.values()) {
    if (member.seat !== null) members.set(member.seat, member);
  }
  return members;
}

function online(role, now) {
  return Boolean(role && now - role.seenAt < presenceMs);
}

function canStart(room, now) {
  const count = [...occupied(room).values()].filter(role => online(role, now)).length;
  return room.game.roundOrder.includes('relay') ? count === 3 : count > 0;
}

function allowedActions(room, role, now) {
  const { phase, round, player, selection } = room.game;
  if (phase === 'setup') return role.host ? (canStart(room, now) ? ['start'] : []) : ['leave'];
  if (room.pending) return [];
  if (phase === 'complete') return role.host ? ['rematch'] : [];
  if (phase === 'buzzerResult') {
    if (!role.host) return [];
    return room.game.index + 1 < room.game.packs.buzzer.length ? ['next', 'release-next'] : ['next'];
  }
  if (phase === 'roundResult') return role.host ? ['next'] : [];
  if (phase === 'intro') return (round === 'relay' ? role.seat === player : role.host) ? ['ready'] : [];
  if (phase === 'handoff') return role.seat === player ? ['handoff'] : [];
  if (phase !== 'question' || role.seat === null || (round === 'relay' && role.seat !== player)) return [];
  const allowed = ['select'];
  if (selection.length) allowed.push('submit');
  if (round !== 'buzzer') allowed.push('skip');
  return allowed;
}

function advanceClock(room, now) {
  if (room.pending) {
    if (now < room.pending.resolveAt) return;
    room.pending = null;
    room.revision += 1;
    return;
  }
  if (room.game.deadline === null || now < room.game.deadline) return;
  engine.dispatch(room.game, { type: 'tick' }, now);
  room.revision += 1;
}

function liveResult(result) {
  if (!result) return null;
  const { question, selection, ...safe } = result;
  return safe;
}

function roomSnapshot(room, role, now) {
  const { seed, ...view } = engine.snapshot(room.game, now);
  view.bankCount = bank.length;
  const active = view.round !== 'relay' || view.player === role.seat;
  if (view.question) {
    if (active && role.seat !== null) {
      const { id, type, stem, options } = view.question;
      view.question = { id, type, stem, options };
    } else {
      view.question = null;
      view.selection = [];
      view.selected = 0;
      view.points = null;
    }
  }

  if (view.phase !== 'complete') {
    const records = room.pending ? view.records.slice(0, -1) : view.records;
    view.records = records.map(({ round, index, outcome }) => ({ round, index, outcome: ['correct', 'wrong'].includes(outcome) ? 'submitted' : outcome }));
    view.lastResult = view.phase === 'buzzerResult' && !room.pending ? liveResult(view.lastResult) : null;
    const finished = view.roundOrder.slice(0, view.roundIndex + Number(view.phase === 'roundResult'));
    view.roundScores = Object.fromEntries(Object.entries(view.roundScores).filter(([round]) => finished.includes(round)));
    view.totalScore = Object.values(view.roundScores).reduce((sum, score) => sum + score, 0);
  }

  if (room.pending) {
    view.phase = 'buzzerWaiting';
    view.hasClock = true;
    view.remainingMs = Math.max(0, room.pending.deadline - now);
    view.submittedElapsedMs = room.game.lastResult.elapsedMs;
  }

  const seatsByNumber = occupied(room);
  return {
    code: room.code, host: role.host, seat: role.seat, recoveryCode: role.recoveryCode,
    seats: seats.map(seat => {
      const member = seatsByNumber.get(seat);
      return { seat, name: member?.name || '', occupied: Boolean(member), online: online(member, now) };
    }),
    hostOnline: online([...room.members.values()].find(member => member.host), now),
    view, allowed: [...allowedActions(room, role, now), ...(role.host ? ['end'] : [])],
    started: view.phase !== 'setup', revision: room.revision, serverNow: now,
  };
}

function act(room, role, data, now) {
  if (data.type === 'start' && role.host && room.game.phase === 'setup' && !canStart(room, now)) throw failure(409, '请等所需座位全部在线后开赛。', roomSnapshot(room, role, now));
  const { round, deadline, openedAt, index, phase } = room.game;
  const currentQuestion = phase === 'question' ? room.game.packs[round][index] : null;
  const explicit = data.type === 'select' && (data.selected !== undefined || data.questionId !== undefined);
  if (explicit && (typeof data.selected !== 'boolean' || typeof data.questionId !== 'string')) throw failure(400, '请选择操作和题号。');
  const currentIntent = explicit && currentQuestion?.id === data.questionId;
  const validStaleIntent = currentIntent && round !== 'relay' && Number.isInteger(data.revision) && data.revision >= room.questionRevision && data.revision < room.revision;
  if ((explicit && !currentIntent) || (data.revision !== room.revision && !validStaleIntent)) {
    throw failure(409, '比赛已同步到新状态，请查看当前页面。', roomSnapshot(room, role, now));
  }
  if (!allowedActions(room, role, now).includes(data.type)) throw failure(403, '当前阶段无法由这台电脑执行该操作。', roomSnapshot(room, role, now));
  if (data.type === 'rematch') {
    const { mode, difficulty, opponents } = room.game;
    room.game = engine.create(bank, { mode, difficulty, opponents });
    room.revision += 1;
    return;
  }
  if (data.type === 'select') {
    if (!currentQuestion.options.some(option => option.key === data.option)) throw failure(400, '这个选项不属于当前题。');
    // 重试同一个动作时保持原状。单选取消时，仅取消用户看到的那一项。
    if (explicit && room.game.selection.includes(data.option) === data.selected) return;
  }
  if (data.type === 'release-next') {
    engine.dispatch(room.game, { type: 'next' }, now);
    engine.dispatch(room.game, { type: 'ready' }, now);
  } else {
    engine.dispatch(room.game, { type: data.type, option: data.option }, now);
  }
  if (round === 'buzzer' && data.type === 'submit') {
    const opponentTimes = room.game.field[index].map(opponent => opponent.elapsedMs ?? engine.constants.buzzerTime);
    const resolveAt = Math.min(deadline, openedAt + Math.max(...opponentTimes));
    if (resolveAt > now) room.pending = { resolveAt, deadline };
  }
  room.revision += 1;
  if (room.game.phase === 'question' && (phase !== 'question' || index !== room.game.index)) room.questionRevision = room.revision;
}

function createServer(options = {}) {
  const now = options.now ?? Date.now;
  const rooms = new Map();

  const server = http.createServer({ requestTimeout: 15000, headersTimeout: 8000 }, async (request, response) => {
    try {
      const url = new URL(request.url, 'http://localhost');
      if (request.method === 'GET' && (url.pathname === '/' || url.pathname === `/${encodeURIComponent(pageName)}`)) {
        const html = await readFile(pagePath);
        response.writeHead(200, {
          'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
          'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
          'Content-Security-Policy': "default-src 'none'; connect-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
        });
        response.end(html);
        return;
      }
      if (request.method === 'GET' && url.pathname === '/api/info') {
        const { port } = server.address();
        sendJSON(response, 200, { addresses: lanAddresses(port), port, bankCount: bank.length });
        return;
      }

      if (request.method === 'POST' && url.pathname === '/api/rooms') {
        const data = await readJSON(request);
        const received = now();
        for (const [code, room] of rooms) if (received - room.touched > idleMs) rooms.delete(code);
        if (rooms.size >= maxRooms) throw failure(503, '房间数量已达上限，请结束不用的房间。');
        const hostSeat = data.hostSeat === null ? null : (data.hostSeat ?? 1);
        if (hostSeat !== null && !seats.includes(hostSeat)) throw failure(400, '请选择有效的主持人座位。');
        let code;
        do { code = randomCode(6); } while (rooms.has(code));
        const { mode, difficulty, opponents } = data;
        const room = { code, game: engine.create(bank, { mode, difficulty, opponents }), touched: received, revision: 0, questionRevision: 0, pending: null, members: new Map() };
        const role = participant(room, data.name, hostSeat, true, received);
        room.members.set(role.token, role);
        rooms.set(code, room);
        sendJSON(response, 201, { ...roomSnapshot(room, role, received), token: role.token });
        return;
      }

      const route = /^\/api\/rooms\/([A-Z0-9]{6})\/(join|recover|state|action)$/i.exec(url.pathname);
      if (!route) throw failure(404, '找不到这个房间页面。');
      const [, lookup, endpoint] = route;
      const code = lookup.toUpperCase();
      const body = request.method === 'POST' && endpoint !== 'state' ? await readJSON(request) : null;
      const received = now();
      const room = rooms.get(code);
      if (!room || received - room.touched > idleMs) {
        rooms.delete(code);
        throw failure(404, '房间已结束，或房间码有误。');
      }

      if (request.method === 'POST' && endpoint === 'join') {
        if (room.game.phase !== 'setup') throw failure(409, '房间已开赛，请用座位恢复码回到原座位。');
        const taken = occupied(room);
        const seat = body.seat === undefined ? [2, 3, 1].find(number => !taken.has(number)) : body.seat;
        if (body.seat === undefined && seat === undefined) throw failure(409, '三个座位都有人了。已有座位的队员可以用恢复码回来。');
        if (!seats.includes(seat)) throw failure(400, '请选择第 1、2 或 3 位队员。');
        if (taken.has(seat)) throw failure(409, '这个座位已有人，请使用房主发的通用邀请链接。');
        const role = participant(room, body.name, seat, false, received);
        room.members.set(role.token, role);
        room.revision += 1;
        room.touched = received;
        sendJSON(response, 201, { ...roomSnapshot(room, role, received), token: role.token });
        return;
      }

      if (request.method === 'POST' && endpoint === 'recover') {
        const code = typeof body.recoveryCode === 'string' ? body.recoveryCode.replace(/[\s-]/g, '').toUpperCase() : '';
        const role = code.length === recoveryLength && ownerOfRecoveryCode(room, code);
        if (!role) throw failure(401, '座位恢复码有误。');
        room.members.delete(role.token);
        role.token = newToken();
        role.seenAt = received;
        room.members.set(role.token, role);
        room.touched = received;
        advanceClock(room, received);
        sendJSON(response, 200, { ...roomSnapshot(room, role, received), token: role.token });
        return;
      }

      const token = /^Bearer ([A-Za-z0-9_-]{32})$/.exec(request.headers.authorization || '')?.[1];
      const role = room.members.get(token);
      if (!role) throw failure(401, '本机座位会话已失效，请使用座位恢复码。');
      room.touched = received;
      role.seenAt = received;
      advanceClock(room, received);
      if (request.method === 'GET' && endpoint === 'state') {
        sendJSON(response, 200, roomSnapshot(room, role, received));
        return;
      }
      if (request.method === 'POST' && endpoint === 'action') {
        if (body.type === 'end' && role.host) {
          rooms.delete(code);
          sendJSON(response, 200, { ended: true });
          return;
        }
        if (body.type === 'leave' && allowedActions(room, role, received).includes('leave')) {
          room.members.delete(role.token);
          room.revision += 1;
          sendJSON(response, 200, { ended: true });
          return;
        }
        act(room, role, body, received);
        sendJSON(response, 200, roomSnapshot(room, role, received));
        return;
      }
      throw failure(405, '房间操作方法有误。');
    } catch (error) {
      if (!error.status) console.error(error.message);
      if (!response.headersSent) sendJSON(response, error.status ?? 500, { error: error.status ? error.message : '主机暂时无法响应。', ...error.snapshot });
    }
  });
  return server;
}

if (require.main === module) {
  const flag = process.argv.indexOf('--port');
  const port = Number((flag >= 0 ? process.argv[flag + 1] : process.env.FINALS_PORT) ?? defaultPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    console.error('端口应为 1 至 65535 之间的整数。');
    process.exitCode = 1;
  } else {
    const server = createServer();
    server.on('error', error => {
      console.error(error.code === 'EADDRINUSE' ? `端口 ${port} 已被占用。可用 --port 8766 切换端口。` : `主机启动失败：${error.message}`);
      process.exitCode = 1;
    });
    server.listen(port, '0.0.0.0', () => {
      console.log(`本机打开 http://localhost:${port}`);
      const addresses = lanAddresses(port);
      for (const address of addresses) console.log(`队员电脑打开 ${address}`);
      if (!addresses.length) console.log('当前未发现可用的局域网 IPv4 地址。');
      console.log('请保持此窗口开启；关闭后房间会结束。');
    });
  }
}

module.exports = { createServer };
