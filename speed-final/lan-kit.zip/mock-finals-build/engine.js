(function (root) {
  'use strict';

  const rounds = Object.freeze(['relay', 'buzzer', 'ai']);
  const scoring = Object.freeze({ multiple: 4, single: 2.5, judge: 1 });
  const maximums = Object.freeze({ relay: 50, buzzer: 25, ai: 25 });
  const shortPack = Object.freeze({ multiple: 1, single: 3, judge: 1 });
  const longPack = Object.freeze({ multiple: 3, single: 4, judge: 3 });
  const relaySegments = Object.freeze([shortPack, shortPack, longPack]);
  const playerTime = 6 * 60 * 1000;
  const buzzerTime = 60 * 1000;
  const aiTime = 10 * 60 * 1000;
  const difficulties = Object.freeze({
    relaxed: { accuracy: 0.62, speed: 1.35 },
    standard: { accuracy: 0.76, speed: 1 },
    fast: { accuracy: 0.88, speed: 0.7 },
  });

  function randomFrom(seed) {
    let value = seed >>> 0;
    return function () {
      value = (value + 0x6D2B79F5) | 0;
      let mixed = Math.imul(value ^ (value >>> 15), value | 1);
      mixed ^= mixed + Math.imul(mixed ^ (mixed >>> 7), mixed | 61);
      return ((mixed ^ (mixed >>> 14)) >>> 0) / 4294967296;
    };
  }

  function shuffle(items, random) {
    const shuffled = items.slice();
    for (let end = shuffled.length - 1; end > 0; end -= 1) {
      const index = Math.floor(random() * (end + 1));
      [shuffled[index], shuffled[end]] = [shuffled[end], shuffled[index]];
    }
    return shuffled;
  }

  function stemKey(question) {
    return question.stem.normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{Z}]/gu, '');
  }

  function questionPack(pool, distribution, usedStems, random) {
    const pack = [];
    for (const [type, count] of Object.entries(distribution)) {
      let taken = 0;
      for (const question of pool) {
        if (question.type !== type) continue;
        const key = stemKey(question);
        if (usedStems.has(key)) continue;
        pack.push(question);
        usedStems.add(key);
        taken += 1;
        if (taken === count) break;
      }
      if (taken < count) throw new Error(`题库中可用的${{ multiple: '多选', single: '单选', judge: '判断' }[type]}题不足（需要 ${count} 题，找到 ${taken} 题）。`);
    }
    return shuffle(pack, random);
  }

  function simulatedField(question, count, difficulty, random) {
    const profile = difficulties[difficulty];
    const baseTime = { multiple: 31000, single: 22000, judge: 14500 }[question.type];
    const accuracyAdjustment = { multiple: -0.13, single: 0, judge: 0.08 }[question.type];
    return Array.from({ length: count }, (_, index) => {
      const time = Math.round(baseTime * profile.speed * (0.25 + random() + random()) / 25) * 25;
      const answered = time < buzzerTime && random() >= 0.07;
      return {
        index: index + 1,
        elapsedMs: answered ? time : null,
        correct: answered && random() < profile.accuracy + accuracyAdjustment,
      };
    });
  }

  function create(bank, settings = {}) {
    const mode = rounds.includes(settings.mode) ? settings.mode : 'full';
    const difficulty = Object.hasOwn(difficulties, settings.difficulty) ? settings.difficulty : 'standard';
    const opponents = Number(settings.opponents) === 15 ? 15 : 7;
    const seed = Number.isFinite(settings.seed) ? settings.seed >>> 0 : Math.floor(Math.random() * 4294967296);
    const random = randomFrom(seed);
    const roundOrder = mode === 'full' ? [...rounds] : [mode];
    const pool = shuffle(bank, random);
    const usedStems = new Set();
    const packs = {};

    // Draw the specialized questions first to preserve enough eligible AI material.
    if (roundOrder.includes('ai')) packs.ai = questionPack(pool.filter(question => question.ai), longPack, usedStems, random);
    if (roundOrder.includes('relay')) {
      packs.relay = relaySegments.flatMap(distribution => questionPack(pool, distribution, usedStems, random));
    }
    if (roundOrder.includes('buzzer')) packs.buzzer = questionPack(pool, longPack, usedStems, random);

    return {
      mode, difficulty, opponents, seed, roundOrder, packs,
      field: (packs.buzzer || []).map(question => simulatedField(question, opponents, difficulty, random)),
      round: roundOrder[0], roundIndex: 0, index: 0, player: mode === 'full' || mode === 'relay' ? 1 : null,
      phase: 'setup',
      records: [],
      roundScores: { relay: 0, buzzer: 0, ai: 0 },
      selection: [],
      bankedMs: 0,
      limitMs: 0,
      deadline: null,
      openedAt: null,
      lastResult: null,
    };
  }

  function currentQuestion(state) {
    return state.packs[state.round][state.index];
  }

  function segmentStart(player) {
    return player === 3 ? 10 : (player - 1) * 5;
  }

  function segmentEnd(state) {
    if (state.player === 1) return 5;
    if (state.player === 2) return 10;
    return state.packs[state.round].length;
  }

  function stopClock(state) {
    state.deadline = null;
    state.openedAt = null;
  }

  function setClock(state, now, duration) {
    state.limitMs = duration;
    state.deadline = now + duration;
  }

  function openQuestion(state, now) {
    state.phase = 'question';
    state.selection = [];
    state.openedAt = now;
  }

  function beginSegment(state, now) {
    if (state.round === 'relay') setClock(state, now, playerTime + (state.player === 3 ? state.bankedMs : 0));
    if (state.round === 'ai') setClock(state, now, aiTime);
    if (state.round === 'buzzer') setClock(state, now, buzzerTime);
    openQuestion(state, now);
  }

  function nextPlayer(state) {
    state.player += 1;
    state.index = segmentStart(state.player);
    state.phase = 'intro';
    stopClock(state);
  }

  function endRound(state) {
    state.phase = 'roundResult';
    stopClock(state);
  }

  function nextRound(state) {
    if (state.roundIndex + 1 === state.roundOrder.length) {
      state.phase = 'complete';
      return;
    }
    state.roundIndex += 1;
    state.round = state.roundOrder[state.roundIndex];
    state.index = 0;
    state.player = null;
    state.limitMs = 0;
    state.lastResult = null;
    state.phase = 'intro';
  }

  function buzzerRank(state, outcome, elapsedMs) {
    const opponents = state.field[state.index];
    const correctOpponents = opponents.filter(opponent => opponent.correct);
    const fieldCorrect = correctOpponents.length + Number(outcome === 'correct');
    const fieldScoring = Math.ceil(fieldCorrect / 2);
    // An identical measured time is ranked by team number; the local team is team 1.
    const faster = correctOpponents.filter(opponent => opponent.elapsedMs < elapsedMs).length;
    const rank = outcome === 'correct' ? faster + 1 : null;
    return {
      rank, fieldCorrect, fieldScoring, opponentCorrect: correctOpponents.length,
      opponentAnswered: opponents.filter(opponent => opponent.elapsedMs !== null).length,
      qualified: rank !== null && rank <= fieldScoring,
    };
  }

  function recordQuestion(state, outcome, now) {
    const question = currentQuestion(state);
    const maxPoints = scoring[question.type];
    const selection = outcome === 'unopened' ? [] : [...state.selection];
    const elapsedMs = outcome === 'unopened' ? null : Math.max(0, now - state.openedAt);
    const result = {
      round: state.round, player: state.player, index: state.index, question, selection,
      outcome, points: 0, maxPoints, elapsedMs,
    };
    if (state.round === 'buzzer') {
      Object.assign(result, buzzerRank(state, outcome, elapsedMs));
      if (result.qualified) result.points = maxPoints;
      if (outcome === 'wrong') result.points = -maxPoints;
    } else {
      if (outcome === 'correct') result.points = maxPoints;
      if (outcome !== 'correct' && outcome !== 'unopened' && state.player !== 1 && state.player !== 2) {
        result.points = -maxPoints;
      }
    }
    state.records.push(result);
    state.lastResult = result;
    state.roundScores[state.round] += result.points;
  }

  function endBuzzerQuestion(state) {
    state.phase = 'buzzerResult';
    stopClock(state);
  }

  function finishQuestion(state, outcome, now) {
    recordQuestion(state, outcome, now);
    if (state.round === 'buzzer') {
      endBuzzerQuestion(state);
      return;
    }

    state.index += 1;
    if (state.index < segmentEnd(state)) {
      openQuestion(state, now);
    } else if (state.player === 1 || state.player === 2) {
      state.phase = 'handoff';
    } else {
      endRound(state);
    }
  }

  function expire(state, now) {
    if (state.deadline === null || now < state.deadline) return;
    if (state.phase === 'handoff') {
      nextPlayer(state);
      return;
    }
    recordQuestion(state, 'timeout', state.deadline);
    if (state.round === 'buzzer') {
      endBuzzerQuestion(state);
      return;
    }

    state.index += 1;
    while (state.index < segmentEnd(state)) {
      recordQuestion(state, 'unopened', state.deadline);
      state.index += 1;
    }
    if (state.player === 1 || state.player === 2) nextPlayer(state);
    else endRound(state);
  }

  function select(state, option) {
    const question = currentQuestion(state);
    if (!question.options.some(item => item.key === option)) return;
    if (state.selection.includes(option)) {
      state.selection = state.selection.filter(key => key !== option);
    } else {
      if (question.type !== 'multiple') state.selection = [];
      state.selection.push(option);
    }
  }

  function scoreSelection(state) {
    const correct = currentQuestion(state).answer;
    return state.selection.length === correct.length && state.selection.every(key => correct.includes(key)) ? 'correct' : 'wrong';
  }

  function step(state, action, now) {
    if (state.phase === 'setup' && action.type === 'start') {
      state.phase = 'intro';
    } else if (state.phase === 'intro' && action.type === 'ready') {
      beginSegment(state, now);
    } else if (state.phase === 'handoff' && action.type === 'handoff') {
      state.bankedMs += state.deadline - now;
      nextPlayer(state);
    } else if (state.phase === 'buzzerResult' && action.type === 'next') {
      if (state.index + 1 === state.packs.buzzer.length) {
        endRound(state);
      } else {
        state.index += 1;
        state.phase = 'intro';
      }
    } else if (state.phase === 'roundResult' && action.type === 'next') {
      nextRound(state);
    } else if (state.phase === 'question') {
      if (action.type === 'select') select(state, action.option);
      if (action.type === 'submit' && state.selection.length) finishQuestion(state, scoreSelection(state), now);
      if (action.type === 'skip' && state.round !== 'buzzer') finishQuestion(state, 'skipped', now);
    }
  }

  function dispatch(state, action, now = Date.now()) {
    const previousPhase = state.phase;
    expire(state, now);
    // An input arriving at the deadline belongs to the expired screen.
    if (state.phase === previousPhase) step(state, action, now);
    return state;
  }

  function snapshot(state, now = Date.now()) {
    const inQuestion = state.phase === 'question';
    const question = inQuestion ? currentQuestion(state) : null;
    const hasClock = state.deadline !== null;
    const segmentTotal = state.player === 1 || state.player === 2 ? 5 : 10;
    const segmentIndex = state.player === null ? state.index : state.index - segmentStart(state.player);
    const selection = [...state.selection];
    const roundScores = { ...state.roundScores };
    return {
      mode: state.mode, difficulty: state.difficulty, opponents: state.opponents, seed: state.seed,
      phase: state.phase, round: state.round, roundIndex: state.roundIndex, roundOrder: [...state.roundOrder],
      player: state.player, index: state.index, segmentIndex, segmentTotal,
      question, selection, points: question ? scoring[question.type] : null, selected: selection.length,
      hasClock, remainingMs: hasClock ? Math.max(0, state.deadline - now) : null,
      limitMs: state.limitMs, segmentLimitMs: state.limitMs, bankedMs: state.bankedMs,
      roundScores, lastResult: state.lastResult, records: [...state.records],
      roundMax: maximums[state.round], roundTotal: state.packs[state.round].length,
      totalMax: state.roundOrder.reduce((total, round) => total + maximums[round], 0),
      totalScore: Object.values(roundScores).reduce((total, points) => total + points, 0),
    };
  }

  root.FinalsEngine = Object.freeze({
    create, dispatch, snapshot,
    constants: Object.freeze({ rounds, scoring, maximums, playerTime, buzzerTime, aiTime }),
  });
})(globalThis);
