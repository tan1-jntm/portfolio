@echo off
setlocal
chcp 65001 >nul
set "FINALS_START=%~dp0mock-finals-build\start-lan.cjs"
where node.exe >nul 2>nul
if %errorlevel% equ 0 (
  node.exe "%FINALS_START%" %*
) else if exist "%USERPROFILE%\nodejs\node.exe" (
  "%USERPROFILE%\nodejs\node.exe" "%FINALS_START%" %*
) else (
  echo 主机需要 Node.js 22 或更新版本。只需在开房的电脑上安装，队友用浏览器即可。
  pause
  exit /b 1
)
if errorlevel 1 pause
